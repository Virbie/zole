let cards = []; // Array for card objects
let placedCards = [] // PRIEKS noliktam kartim
let placedCardsPlayer = [] // lai katrai kartij pieliktu kada speletaja vertibu
let container = document.getElementById("cardcontainer"); // Card container element
let placedCardsContainer = document.getElementById("kartisUzGalda") // kartis kas noliktas uz galda
let gajiensPecKartas = 1

let punktiDiv = document.getElementById("acisSpeletaji")

const mainButton = document.getElementById('KartisDala');
mainButton.addEventListener('click', () => {
  mainButton.style.display = 'none'; // Hide the button
  secondButton.style.display= 'inline-block';
  displayCards()
});
//test
const secondButton = document.getElementById('SacSpeli');
secondButton.addEventListener('click', () => {
  secondButton.style.display = 'none'; // Hide the button
  Gajiens()
});

const velreizPoga = document.getElementById('velreiz')
velreizPoga.addEventListener('click', () =>{
  velreizPoga.style.display= 'none';
  displayCards()
  Gajiens()
})


let delayGajiens = 200

function Gajiens() {
    console.log("atkal");
    if (gajiensPecKartas === 9) {
        raundaUzvaretajsParb();
        punktiDiv.innerHTML = "";
        punktiDiv.appendChild(document.createTextNode(raundaUzvaretajs));
    
        gajiensPecKartas = 1;
        velreizPoga.style.display = 'inline-block';
        return; // No more moves
    }
    
    if (placedCards.length === 3) {
        GajienaUzvaretajs(placedCards, placedCardsPlayer);
        acisSumma(placedCards);
        gajiensPecKartas += 1;
    
        console.log(placedCards);
        console.log(placedCardsPlayer);
    
        placedCards = [];
        placedCardsPlayer = [];
        placedCardsContainer.innerHTML = "";
    
        playerGajienaID = GajienaUzvaretajsPlayer;
        console.log(GajienaUzvaretajsPlayer);
    
        punktiDiv.innerHTML = "";
        punktiDiv.appendChild(document.createTextNode(playerAcis));
    
        setTimeout(Gajiens, delayGajiens); // Go to next move after clearing
        return;
    }
    
    switch (playerGajienaID) {
        case 1:
            container.addEventListener("click", function playerClick(event) {
                if (event.target.classList.contains("card")) {
                    // Get the card number from the image source
                    const cardNumber = parseInt(event.target.src.split("/").pop().replace(".png", ""));
                    
                    // Get current position of the clicked card
                    const cardRect = event.target.getBoundingClientRect();
                    const containerRect = placedCardsContainer.getBoundingClientRect();
                    
                    // Create a clone of the clicked card for the animation
                    const cardClone = event.target.cloneNode(true);
                    cardClone.classList.add('card-flying');
                    cardClone.style.position = 'fixed';
                    cardClone.style.left = cardRect.left + 'px';
                    cardClone.style.top = cardRect.top + 'px';
                    cardClone.style.width = cardRect.width + 'px';
                    cardClone.style.height = cardRect.height + 'px';
                    // Important: Remove any existing transform to start fresh
                    cardClone.style.transform = '';
                    document.body.appendChild(cardClone);
                    
                    // Calculate destination (center of the placed cards container)
                    const destX = containerRect.left + (containerRect.width / 2) - (cardRect.width / 2);
                    const destY = containerRect.top + (containerRect.height / 2) - (cardRect.height / 2);
                    
                    // Generate random rotation for flying animation
                    const randomRotate = Math.random() * 360;
                    
                    // Store the final rotation and position for landing
                    const finalData = {
                        x: destX,
                        y: destY,
                        rotation: randomRotate,
                        cardNumber: cardNumber
                    };
                    
                    // Start the flying animation WITHOUT scaling to prevent size changes
                    setTimeout(() => {
                        cardClone.style.transform = `translate(${destX - cardRect.left}px, ${destY - cardRect.top}px) rotate(${randomRotate}deg)`;
                    }, 10);
                    
                    // Remove the original card
                    event.target.remove();
                    
                    // Update the game state
                    placedCards.push(cardNumber);
                    placedCardsPlayer.push(1);
                    
                    // After animation completes
                    setTimeout(() => {
                        // Remove the clone
                        cardClone.remove();
                        
                        // Add the card to the table with the same rotation
                        addCardToTable(finalData, 1);
                        
                        // Rearrange the remaining cards
                        arrangeCardsInArc();
                        
                        // Move to next player
                        playerGajienaID = 2;
                        setTimeout(Gajiens, delayGajiens);
                    }, 600); // Match this with the CSS transition time
                } else {
                    Gajiens();
                }
            }, { once: true });
            break;
            
        // Bot cases remain the same...
        case 2:
            // Add a small delay to make bot's move feel more natural
            setTimeout(() => {
                Bots2(parseInt(placedCards[0])); 
                
                // Simulate a card placement with animation
                simulateBotCardPlacement(bot2PlacedNumber, 2);
                
                playerGajienaID = 3;
                setTimeout(Gajiens, delayGajiens + 600); // additional delay for animation
            }, 300);
            break;
    
        case 3:
            // Add a small delay to make bot's move feel more natural
            setTimeout(() => {
                Bots3(parseInt(placedCards[0])); 
                
                // Simulate a card placement with animation
                simulateBotCardPlacement(bot3PlacedNumber, 3);
                
                playerGajienaID = 1;
                setTimeout(Gajiens, delayGajiens + 600); // additional delay for animation
            }, 300);
            break;
    }
}

function simulateBotCardPlacement(cardNumber, playerID) {
    // Create a temporary card element for animation
    const tempCard = document.createElement('img');
    tempCard.src = `./resources/${cardNumber}.png`;
    tempCard.width = 150;
    tempCard.height = 250;
    tempCard.classList.add('card-flying');
    
    // Set initial position based on which bot is playing
    const containerRect = placedCardsContainer.getBoundingClientRect();
    const centerX = containerRect.left + (containerRect.width / 2) - 75;
    const centerY = containerRect.top + (containerRect.height / 2) - 125;
    
    // Different starting positions based on player ID
    let startX, startY;
    if (playerID === 2) {
        // Bot 2 starts from left
        startX = containerRect.left - 200;
        startY = containerRect.top;
    } else {
        // Bot 3 starts from right
        startX = containerRect.right + 200;
        startY = containerRect.top;
    }
    
    tempCard.style.position = 'fixed';
    tempCard.style.left = startX + 'px';
    tempCard.style.top = startY + 'px';
    tempCard.style.zIndex = '100';
    document.body.appendChild(tempCard);
    
    // Generate random rotation for flying animation
    const randomRotate = Math.random() * 360;
    
    // Store the final data for landing
    const finalData = {
        x: centerX,
        y: centerY,
        rotation: randomRotate,
        cardNumber: cardNumber
    };
    
    // Start the flying animation with NO scaling to prevent size change
    setTimeout(() => {
        tempCard.style.transform = `translate(${centerX - startX}px, ${centerY - startY}px) rotate(${randomRotate}deg)`;
    }, 10);
    
    // Update the game state
    placedCards.push(cardNumber);
    placedCardsPlayer.push(playerID);
    
    // After animation completes
    setTimeout(() => {
        // Remove the animation card
        tempCard.remove();
        
        // Add card to table with the same rotation
        addCardToTable(finalData, playerID);
        
    }, 600); // Match this with the CSS transition time
}

// New function to add cards to table with fixed position and rotation
function addCardToTable(cardData, playerID) {
    const img = document.createElement("img");
    img.src = "./resources/" + cardData.cardNumber + ".png";
    img.classList.add("placed");
    img.width = 150;
    img.height = 250;
    
    // Apply small random offset to prevent exact overlap
    const offsetX = Math.random() * 20 - 10;
    const offsetY = Math.random() * 20 - 10;
    
    // Set position based on the landing coordinates
    img.style.position = 'absolute';
    img.style.left = `${cardData.x - placedCardsContainer.getBoundingClientRect().left + offsetX}px`;
    img.style.top = `${cardData.y - placedCardsContainer.getBoundingClientRect().top + offsetY}px`;
    
    // Apply the rotation that was used during flight
    img.style.transform = `rotate(${cardData.rotation}deg)`;
    
    // Set z-index based on current number of cards
    img.style.zIndex = (placedCardsContainer.children.length + 10).toString();
    
    // Add to the container
    placedCardsContainer.appendChild(img);
}

// Updated displayCards function
function displayCards() {
    Karsudalisana(); // Call the function from backend.js
    container.innerHTML = "";
    
    for (let i = 0; i < 8; i++) {
        const img = document.createElement("img");
        img.src = "./resources/" + player1[i] + ".png"; // Image source
        img.id = "card" + i; // Optional ID
        img.classList.add("card"); // Add card class
        img.width = 150;
        img.height = 250;
        container.appendChild(img); // Add card to the container
    }
    
    // Wait a brief moment for images to load before arranging
    setTimeout(() => {
        arrangeCardsInArc();
        setupCardHoverEffects();
    }, 50);
}

function setupCardHoverEffects() {
    document.querySelectorAll(".card").forEach((card) => {
        // Track if we're hovering to avoid animation conflicts
        let isHovering = false;
        
        card.addEventListener("mouseenter", () => {
            isHovering = true;
            
            // Get original angle and store it
            const angle = parseFloat(card.dataset.angle || 0);
            const hoverOffset = -25; // Slightly smaller offset for subtlety
            
            // Apply smooth transition
            card.style.transition = "transform 0.25s cubic-bezier(0.175, 0.885, 0.32, 1.275)";
            card.style.transform = `rotate(${angle}deg) translateY(${hoverOffset}px)`;
            
            // No bouncing animation - keeping it simple and smooth
        });
        
        card.addEventListener("mouseleave", () => {
            isHovering = false;
            
            // Return to original position with a nice easing
            card.style.transition = "transform 0.2s cubic-bezier(0.215, 0.61, 0.355, 1)";
            card.style.transform = card.dataset.baseTransform || '';
        });
    });
}

function clearPlacedCards(){
  placedCards = []
}

// No longer needed as we're using addCardToTable instead
function refresh() {
    // This function is now a no-op as cards are added individually
    // with fixed positions and rotations when they land
}

function arrangeCardsInArc() {
    const cards = document.querySelectorAll(".card");
    const total = cards.length;
    
    // Exit if no cards
    if (total === 0) return;
    
    // Get container dimensions
    const containerRect = container.getBoundingClientRect();
    const containerWidth = containerRect.width;
    
    // Calculate center point and base position
    const centerX = containerWidth / 2;
    const baseY = 120; // Position from the top
    
    // Adjust arc parameters based on number of cards
    const minRadius = 350; // Minimum radius
    const maxRadius = 600; // Maximum radius 
    const radius = minRadius + ((maxRadius - minRadius) * (1 - total/8)); // Dynamic radius
    
    // Increased spacing between cards
    const maxSpread = Math.min(75, total * 10); // Increased from 60 to 75 for wider spread
    const spread = total > 1 ? maxSpread : 0;
    const minAngle = -spread / 2;
    const maxAngle = spread / 2;
    
    // Flatter arc (less height difference between middle and outer cards)
    const peakOffset = 70; // Reduced from 80 to make arc flatter
    
    // Position each card
    cards.forEach((card, i) => {
        // Handle single card case
        if (total === 1) {
            // Center single card with no rotation
            card.style.position = 'absolute';
            card.style.left = `${centerX - 75}px`; // 75 is half card width
            card.style.top = `${baseY}px`;
            card.style.transform = 'rotate(0deg)';
            card.dataset.baseTransform = 'rotate(0deg)';
            card.dataset.angle = 0; // Store angle for hover effect
            return;
        }
        
        // Calculate the angle for this card - dynamically adjusted
        const angle = minAngle + ((maxAngle - minAngle) / (total - 1)) * i;
        const radians = (angle * Math.PI) / 180;
        
        // Calculate x position with improved spacing
        const x = centerX + radius * Math.sin(radians) - 75; // 75 is half card width
        
        // Calculate y position with flatter arc effect - using a gentler curve
        // This makes the middle and outer cards more level with each other
        let arcOffset = 0;
        if (total > 1) {
            const midpoint = (total - 1) / 2;
            const distanceFromMid = Math.abs(i - midpoint);
            // Using a linear function instead of squared for a flatter arc
            const factor = 1 - (distanceFromMid / midpoint); 
            arcOffset = peakOffset * factor;
        }
        
        // Calculate final y position - cards closer to middle rise slightly higher
        const y = baseY - arcOffset;
        
        // Set position with fixed pixel values
        card.style.position = 'absolute';
        card.style.left = `${Math.round(x)}px`;
        card.style.top = `${Math.round(y)}px`;
        
        // Adjust rotation - less dramatic when fewer cards
        // Cards should fan out, with rotation more extreme at edges
        const rotationFactor = Math.min(0.7, total / 7); // Reduced rotation factor slightly
        const rotationAngle = angle * rotationFactor;
        
        const baseTransform = `rotate(${rotationAngle}deg)`;
        card.style.transform = baseTransform;
        card.dataset.baseTransform = baseTransform;
        card.dataset.angle = rotationAngle; // Store angle for hover effects
    });
}