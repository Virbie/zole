# Ļoti episks zoles projekts
Grupas biedri - Edgars Reichmanis-Norbuts,Rihards Raginskis-Repše un Bruno Kančs

Grupas carry = Aleksandrs


